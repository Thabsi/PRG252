CREATE DATABASE Students

USE Students
GO

CREATE TABLE StudentList(
	StudentNumber INT NOT NULL,
	StudentName VARCHAR(50),
	StudentSurname VARCHAR(50),
	DOB VARCHAR(50),
	Gender VARCHAR(50),
	Phone VARCHAR(50),
	StudentAddress VARCHAR(50),
	ModulesCource VARCHAR(50),
);
USE Students
GO

INSERT INTO StudentList
VALUES
(577009, 'Nicolette', 'Mahlangu', 30/12/98,'Female', 0815233302, 'BelgiumCampus','PRG252'),
(576985, 'Nosipho', 'Moss', 10/01/96, 'Female', 0670542260, 'BelgiumCampus','PRG171'),
(576999, 'Thabsile', 'Thusi', 27/07/20, 'Female',0840924560, 'BelgiumCampus','PRG252');

USE Students
GO
CREATE PROCEDURE SPDisplayStudents
AS
BEGIN
	SELECT * FROM StudentList
END

EXECUTE [dbo].[SPDisplayStudents]
