USE BelgiumCampus
GO
CREATE PROCEDURE spDisplayStudent
AS
BEGIN
	SELECT * FROM StudentList
END

EXECUTE [dbo].[spDisplayStudent]