USE Students
GO
CREATE PROCEDURE spDeleteStudent
(
	@studentID INT
)
AS
BEGIN
	SELECT * FROM StudentList
	WHERE StudentNumber = @studentID
END