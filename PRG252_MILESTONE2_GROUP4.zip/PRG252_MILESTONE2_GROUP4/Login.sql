USE StudentLogin
GO
CREATE PROCEDURE SPDisplayStudent1
AS
BEGIN
	SELECT * FROM StudentList1
END

EXECUTE [dbo].[SPDisplayStudent1]