﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRG252_MILESTONE_2_GROUP4
{
    class DataHandler
    {
        public List<string> format(List<string> data)
        {
            List<Login> person= new List<Login>();

            foreach (string line in data)
            {
                string[] item = line.Split(',');
                Login student = new Login(item[0], item[1]);
                person.Add(student);    
            }
            List<string> formattedData = new List<string>();

            foreach (Login student in person)
            {
                Console.WriteLine(student);
                formattedData.Add(student.ToString());
            }
            return formattedData;
        }
     
        public DataHandler() { }
        string connect = "Data Source=DELL\\SQLEXPRESS; Initial Catalog=Students; Integrated Security=SSPI;";

        SqlConnection con;
        SqlCommand command;
        SqlDataAdapter adapter;

        public DataTable getStudents()
        {
            con = new SqlConnection(connect);
            adapter = new SqlDataAdapter("[spDisplayStudents]", con);  
            
            adapter.SelectCommand.CommandType = CommandType.StoredProcedure;

            DataTable table = new DataTable();
            _ = adapter.Fill(table);

            return table;
        }
        public void addStudent(int id, string n, string s,string dob, string g,string p,string ad, string c)
        {
            try
            {
                using (con = new SqlConnection(connect))
                {
                    command = new SqlCommand("spADDStudent", con);
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("@studentID", id);
                    command.Parameters.AddWithValue("@studentName", n);
                    command.Parameters.AddWithValue("@studentSurname", s);
                    command.Parameters.AddWithValue("@DOB", dob);
                    command.Parameters.AddWithValue("@gender", g);
                    command.Parameters.AddWithValue("@phone", p);
                    command.Parameters.AddWithValue("@address", ad);
                    command.Parameters.AddWithValue("@courseID", c);

                    con.Open();
                    command.ExecuteNonQuery();
                    MessageBox.Show($"Student entered successfully");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        public void UpdateStudent(int id, string n, string s, string dob, string g, string p, string ad, string c)
        {
            try
            {
                using (con = new SqlConnection(connect))
                {
                    command = new SqlCommand("spUpdateStudent", con);
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("@studentID", id);
                    command.Parameters.AddWithValue("@studentName", n);
                    command.Parameters.AddWithValue("@studentSurname", s);
                    command.Parameters.AddWithValue("@DOB", dob);
                    command.Parameters.AddWithValue("@gender", g);
                    command.Parameters.AddWithValue("@phone", p);
                    command.Parameters.AddWithValue("@address", ad);
                    command.Parameters.AddWithValue("@courseID", c);

                    con.Open();
                    command.ExecuteNonQuery();
                    MessageBox.Show($"Student entered successfully");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");

            }

        }
        public void deleteStudent(int id)
        {

            using (con = new SqlConnection(connect))
            {
                command = new SqlCommand("spDeleteStudent", con);
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.AddWithValue("@studentID", id);

                con.Open();
                command.ExecuteNonQuery();
                MessageBox.Show("Data deleted successfully");
            }
        }

        public DataTable SearchStudent(int id)
        {

            using (con = new SqlConnection(connect))
            {
                command = new SqlCommand("spSearchStudent", con);
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.AddWithValue("@studentID", id);

                con.Open();
                DataTable dt = new DataTable();

                using (SqlDataReader dr = command.ExecuteReader())
                {
                    dt.Load(dr);
                    return dt;

                }
            }
           
        }

    }
}
