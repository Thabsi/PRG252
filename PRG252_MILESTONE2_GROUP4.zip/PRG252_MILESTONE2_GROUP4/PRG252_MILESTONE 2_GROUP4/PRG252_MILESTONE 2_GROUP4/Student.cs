﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRG252_MILESTONE_2_GROUP4
{
    public partial class Student : Form
    {
        public Student()
        {
            InitializeComponent();
        }
        DataHandler handler = new DataHandler();
        BindingSource src = new BindingSource();
        Students student = new Students();

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            src.DataSource = handler.getStudents();
            dataGridView1.DataSource = src;
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            student.studentID = int.Parse(txtNumber.Text);
            student.studentName = txtName.Text;
            student.studentSurname = txtSurname.Text;
            student.DOB = txtDOB.Text;
            student.gender = txtGender.Text;
            student.phone = txtPhone.Text;
            student.address = txtAdderss.Text;
            student.courseID = txtCourse.Text;



            handler.addStudent(student.studentID, student.studentName, student.studentSurname, student.DOB, student.gender,student.phone, student.address, student.courseID);

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            student.studentID = int.Parse(txtNumber.Text);
            student.studentName = txtName.Text;
            student.studentSurname = txtSurname.Text;
            student.DOB = txtDOB.Text;
            student.gender = txtGender.Text;
            student.phone = txtPhone.Text;
            student.address = txtAdderss.Text;
            student.courseID = txtCourse.Text;

            handler.UpdateStudent(student.studentID, student.studentName, student.studentSurname, student.DOB, student.gender, student.phone, student.address, student.courseID);

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            student.studentID = int.Parse(txtNumber.Text);
            handler.deleteStudent(student.studentID);


        }

      

        private void btnSearch_Click(object sender, EventArgs e)
        {
            SearchForm p = new SearchForm();    
            p.Show();
        }
      
        private void button1_Click(object sender, EventArgs e)
        {
            FileHandler fh = new FileHandler();
            listBox1.DataSource = fh.Read();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //fh.Write()
        }
    }
}
