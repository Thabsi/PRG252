﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRG252_MILESTONE_2_GROUP4
{
    class Students
    {
        internal int studentID { get; set; }
        internal string studentName { get; set; }
        internal string studentSurname { get; set; }
        internal string DOB { get; set; }
        internal string gender { get; set; }
        internal string phone { get; set; } 
        internal string address { get; set; }   
        internal string courseID { get; set; }  

        public Students()
        {

        }
    }
}
