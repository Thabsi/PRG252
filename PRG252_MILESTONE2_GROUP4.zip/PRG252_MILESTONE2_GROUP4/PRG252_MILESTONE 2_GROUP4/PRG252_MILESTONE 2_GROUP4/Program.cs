﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRG252_MILESTONE_2_GROUP4
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new LoginForm());

            FileHandler fh = new FileHandler();
            DataHandler dh = new DataHandler();

            List<string> infor = new List<string>();
            dh.format(fh.Read());
            fh.Write(infor);

            Console.ReadLine();
        }
    }
}
