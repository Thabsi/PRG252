﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRG252_MILESTONE_2_GROUP4
{
     class Login
    {
        internal string name { get; set; }  
        internal string password { get; set; }

        public Login (string n, string p)
        {
            this.name = n;
            this.password = p;
        }

        public override string ToString()
        {
            return $"Username : {this.name} | Password : {this.password}";
        }
    }
}
