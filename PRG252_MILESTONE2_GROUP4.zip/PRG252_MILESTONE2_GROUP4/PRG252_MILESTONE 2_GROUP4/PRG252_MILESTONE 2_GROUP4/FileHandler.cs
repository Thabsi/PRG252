﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PRG252_MILESTONE_2_GROUP4
{
    class FileHandler
    {
        public List<string> Read()
        {
            List<string> data = new List<string>();
            data = File.ReadAllLines("file.txt").ToList();

            foreach (string line in data)
            {
                Console.WriteLine(line);
            }
            Console.WriteLine();
            return data;
        }

        public void Write(List<string> formattedData)
        {
            Console.WriteLine();
            File.WriteAllLines("newTextFile.txt", formattedData);
            Console.WriteLine("Write to file successful");
        }

    }
}
