USE Students
GO
CREATE PROCEDURE spaddStudent
(
    @studentID INT,
	@studentName VARCHAR(50),
	@studentSurname VARCHAR(50),
	@DOB VARCHAR(50),
	@gender VARCHAR(50),
	@phone VARCHAR(20),
	@address VARCHAR(50),
	@courseID VARCHAR(50)
)
AS
BEGIN
	INSERT INTO StudentList VALUES
	(@studentID, @studentName, @studentSurname,@DOB,@gender,@phone,@address,@courseID)
END