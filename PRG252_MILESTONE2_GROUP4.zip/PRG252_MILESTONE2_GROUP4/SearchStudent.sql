USE Students
GO
CREATE PROCEDURE spSearchStudent
(
    @studentID INT
)
AS
BEGIN
	SELECT * FROM StudentList
	WHERE StudentNumber = @studentID
END