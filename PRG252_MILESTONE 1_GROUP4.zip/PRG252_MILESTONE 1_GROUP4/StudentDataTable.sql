CREATE DATABASE StudentDB

USE StudentDB;
CREATE TABLE StudentDetails(
	StudentNumber int,
	StudentName varchar(50),
	StudentSurname varchar(50),
	DOB varchar(50),
	Gender varchar(50),
	Phone int,
	StudentAddress varchar(50),
	ModulesCource varchar(50),
);
USE StudentDB;
INSERT INTO dbo.StudentDetails
VALUES
(577009, 'Nicolette', 'Mahlangu', 30/12/98,'Female', 0815233302, 'BelgiumCampus','PRG252'),
(576985, 'Nosipho', 'Moss', 10/01/96, 'Female', 0670542260, 'BelgiumCampus','PRG171'),
(576999, 'Thabsile', 'Thusi', 27/07/20, 'Female',0840924560, 'BelgiumCampus','PRG252');

SELECT * FROM dbo.StudentDetails;
