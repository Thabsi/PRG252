﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginAndRegistration
{
    class DataHandler
    {
        public DataHandler() { }

        static string connect = "Data Source=.; Initial Catalog= BelgiumCampusDB; Integrated Security=SSPI;";

        SqlConnection con;
        SqlCommand command; 
        public void Register(int n, string name1, string surname, DateTime dob, string gender, int number, string adderss, string course)
        {
            string query = $"INSERT INTO Students VALUES('{n}', '{name1}', '{surname}', '{dob}' ,'{gender}' ,'{number}' ,'{adderss}', '{course}')";

            con = new SqlConnection(connect);
            con.Open();
            command = new SqlCommand(query, con);

            try
            {
                command.ExecuteNonQuery(); 
                MessageBox.Show("Register Successful");
            }
            catch (Exception ex)
            {

                MessageBox.Show($"Error: {ex}"); 
            }
            finally
            {
                con.Close(); 
            }

        }
        public void Update(int n, string name1, string surname, DateTime dob, string gender, int number, string adderss, string course)
        {
            string query = $"UPDATE Students SET StudendNumber = '{n}', Name = '{name1}', Surname = '{surname}', DOB = '{dob}', Gender = '{gender}', Number= '{number}',Adderss = '{adderss}' Course ='{course}' WHERE StudentNumber='{n}'";

            con = new SqlConnection(connect);
            con.Open();

            command = new SqlCommand(query, con);

            
            try
            {
                command.ExecuteNonQuery(); 
                MessageBox.Show("Update Successful");
            }
            catch (Exception ex)
            {

                MessageBox.Show($"Error: {ex}"); 
            }
            finally
            {
                con.Close(); 
            }

        }
        public DataTable Search(int n)
        {
            string query = $"SELECT * FROM Students WHERE StudentID = '{n}'";
            con = new SqlConnection(connect);

            SqlDataAdapter adapter = new SqlDataAdapter(query, con);

            DataTable table = new DataTable();

            adapter.Fill(table);

            return table;
        }

    }
}
