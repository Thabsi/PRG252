﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace LoginAndRegistration
{
    public partial class Student : Form
    {
        List<string> myStudent = new List<string>();

        BindingSource bs = new BindingSource();
        public Student()
        {
            InitializeComponent();
       
        }

        MainForm students = new MainForm();
        DataHandler handler = new DataHandler();    

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            students.StudentNumber = int.Parse(txtNumber.Text);
            students.StudentName = txtName.Text;
            students.StudentSurname = txtSurname.Text;
            students.DOB = DateTime.Now;
            students.Gender = txtGender.Text;
            students.Phone = int.Parse(txtPhone.Text);
            students.StudentAddress= txtAdderss.Text;
            students.ModulesCource= txtCourse.Text;

            handler.Update(students.StudentNumber, students.StudentName, students.StudentSurname, students.DOB, students.Gender, students.Phone,students.StudentAddress, students.ModulesCource);
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
           SeacrhForm m = new SeacrhForm();
            m.Show();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void btnRead_Click(object sender, EventArgs e)
        {
            
        }
    }
}
