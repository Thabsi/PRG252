﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoginAndRegistration
{
    class MainForm
    {

        internal int StudentNumber { get; set; }    
        internal string StudentName { get; set; }  
        internal string StudentSurname { get; set; }   
        internal DateTime DOB { get; set; }
        internal string Gender { get; set; }    
        internal int Phone { get; set; }
        internal string StudentAddress { get; set; }
        internal string ModulesCource { get; set; }    



        public MainForm() { }

        public MainForm(int n, string name1, string surname, DateTime dob, string gender,int number, string adderss, string course)
        {
          
            this.StudentNumber = n;
            this.StudentName = name1;
            this.StudentSurname = surname;
            this.DOB = dob;
            this.Gender = gender;
            this.Phone = number;
            this.StudentAddress = adderss;
            this.ModulesCource = course;
        }
    }
}
